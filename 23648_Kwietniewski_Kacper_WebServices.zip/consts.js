const LOGIN = 'test';
const PASSWORD = '12341234';
const PRIVATE_KEY = 'someSecretKey';

module.exports = {
    LOGIN,
    PASSWORD,
    PRIVATE_KEY,
};